function jogoPedraPapelTesoura(escolhaUsuario) {


  console.log(escolhaUsuario);

  if (escolhaUsuario === "pedra" || escolhaUsuario === "papel" || escolhaUsuario === "tesoura") {
    const escolhaComputador = escolhaDoComputador();


    const resultado = determinarVencedor(escolhaUsuario, escolhaComputador);
    alert(resultado);
  } else {
    console.log("Escolha inválida. Por favor, escolha entre pedra, papel ou tesoura.");

  }

}
