
function escolhaDoComputador() {
    console.log("hit")
    const opcoes = ["pedra", "papel", "tesoura"];
    const indiceAleatorio = Math.floor(Math.random() * 3);
    return opcoes[indiceAleatorio];
   

  }
  
  function determinarVencedor(escolhaUsuario, escolhaComputador) {
    if (escolhaUsuario === escolhaComputador) {
      return "Empate";
    } else if (
      (escolhaUsuario === "pedra" && escolhaComputador === "tesoura") ||
      (escolhaUsuario === "tesoura" && escolhaComputador === "papel") ||
      (escolhaUsuario === "papel" && escolhaComputador === "pedra")
    ) {
      return "Você ganhou!";
    } else {
      return "O computador ganhou!";
    }
  }
  
  function jogoPedraPapelTesoura(escolhaUsuario) {
  
    
console.log(escolhaUsuario)
  
    if (escolhaUsuario === "pedra" || escolhaUsuario === "papel" || escolhaUsuario === "tesoura") {
      const escolhaComputador = escolhaDoComputador();
      
      
      const resultado = determinarVencedor(escolhaUsuario, escolhaComputador);
      alert(resultado);

    } 
    alet( "O computador escolheu" + escolhaDoComputador());
    alert( "o usuário escolheu" + escolhaUsuario());
  }
  
  jogoPedraPapelTesoura();
  