function Retangulo(x, y) {
    this.x = x;
    this.y = y;

    this.calcArea = function(){
        return this.x * this.y;

    }


}
var retangulo = new Retangulo(12, 40);

alert(retangulo.calcArea());




class Conta{
    constructor(nome, banco, numConta, saldo){

        this.nome = nome;
        this.banco = banco;
        this.numConta = numConta;
        this.saldo = saldo;
    }

}
class Corrente extends Conta{
    setSaldoEspecial(value){
       this.saldoEspecial = value;  
    }
    getSaldoEspecial(){
        return this.saldoEspecial;
    }

}
 class Poupanca extends Conta{
     setJuros(value){
         this.juros = value;

     }
     getJuros(){
         return this.juros;
     }

     setDataVencimento(value){
        this.datavencimento = value;

    }
    getDataVencimento(){
        return this.datavencimento;
    }

 }
 
corrente = new Corrente("Jaquiel","Bradesco","100-99",25000)

corrente.setSaldoEspecial(5000);

poupanca = new Poupanca("heloísa","Itau",2025-19,"2000000");

poupanca.setJuros(0.5);
poupanca.setDataVencimento("30.12.2025");


alert( "O nome é: " + corrente.nome + "\n" + "Banco: " + corrente.banco + " \n" + " numero conta: " + corrente.numConta
+ " \n  saldo: " + corrente.saldo + "\n Saldo espcial:" + corrente.getSaldoEspecial());

alert( "O nome é: " + poupanca.nome + "\n" + "Banco: " + poupanca.banco + " \n" + " numero conta: " + poupanca.numConta
+ " \n  saldo: " + poupanca.saldo + "\n Juros  é: " + poupanca.getJuros() + "\n Data de Vencimento é: " + poupanca.getDataVencimento());







