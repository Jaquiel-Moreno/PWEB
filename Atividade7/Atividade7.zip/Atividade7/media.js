// notas
var nome = prompt("informe seu nome:");



var nota1 = parseFloat(prompt('informe nota 1: '));

var nota2 = parseFloat(prompt('informe nota 2: '));

var nota3 = parseFloat(prompt('informe nota 3: '));

 

var media;

 

function calcularMedia(){

    media = (nota1 + nota2 + nota3) /3;

    return media 

}

 

media = calcularMedia().toFixed(2);

alert(`a media do aluno: ${nome} é a ${media}`);