// operaçoes
var num1 = parseFloat(prompt('informe numero 1: '));

var num2 = parseFloat(prompt('informe numero 2: '));

 

var soma = num1 + num2;

var subtracao = num1 - num2;

var produto = num1 * num2;

var divisao = num1 / num2;

var resto = num1 % num2;

 

alert("Soma: " + soma.toFixed(2));

alert('Subtração: ' + subtracao.toFixed(2));

alert('Produto: ' + produto.toFixed(2));

alert('Divisão: ' + divisao.toFixed(2));

alert('Resto: ' + resto).toFixed(2);

