var  texto = "Observe que essa vem do modulo";
module.exports = texto;