module.exports = function(app){ 
    app.get('/informacao/professores', function(req,res){ 
    const sql = require ('mssql/msnodesqlv8'); 
    const sqlConfig = { 
    user: 'BD2123024', 
    password: 'A12345678a', 
    database: 'LP2', //Na FATEC, utilizar o database BD ou LP8 
    server: 'APOLO',//Caso o nome tenha uma instância, colocar duas 
  
    } 
    
    async function getProfessores() { 
        try { 
        const pool = await sql.connect(sqlConfig); 
        
        const results = await pool.request().query('SELECT * from PROFESSORES') 
        
        res.render('informacao/professores',{profs : results.recordset}); 
        
        } catch (err) { 
        console.log(err) 
        } 
        } 
        getProfessores(); 
        }); 
       } 