
 
        var janela = document.getElementById("janela");
        var janelaTexto = document.getElementById("status");

        janela.addEventListener("mouseover", function () {
            janela.src = "janelaAberta.jfif";
            janelaTexto.textContent = "Janela Aberta";
        });

        janela.addEventListener("mouseout", function () {
            janela.src = "janelaFechada.jpg";
            janelaTexto.textContent = "Janela Fechada";
        });

        janela.addEventListener("click", function () {
            janela.src = "janelaQuebradas.jfif";
            janelaTexto.textContent = "Janela Quebrada";
        });
    

