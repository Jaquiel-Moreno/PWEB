function transformarTexto() {
    let textoInput = document.getElementById('texto');
    let checkboxMaiusculas = document.getElementById('maiusculas');
    let checkboxMinusculas = document.getElementById('minusculas');


    if (checkboxMaiusculas.checked && checkboxMinusculas.checked) {
        return;
    }

    if (checkboxMaiusculas.checked) {
        textoInput.value = textoInput.value.toUpperCase();
    } else if (checkboxMinusculas.checked) {
        textoInput.value = textoInput.value.toLowerCase();
    }
}